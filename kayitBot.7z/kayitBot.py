
import dersAl


donem = 202001
eklenilcekDerslerCrn = dersAl.dersCrnListesiAl()
dersAl.Kaydol(donem,eklenilcekDerslerCrn)









    
        



